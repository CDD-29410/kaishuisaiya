// 该配置对象是配置postcss-loader
module.exports = {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
    }
}